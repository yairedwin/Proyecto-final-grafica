#pragma once
#include<stdio.h>
#include<glew.h>
#include<glfw3.h>

class Window
{
public:
	Window();
	Window(GLint windowWidth, GLint windowHeight);
	int Initialise();
	GLfloat getBufferWidth() { return bufferWidth; }
	GLfloat getBufferHeight() { return bufferHeight; }
	GLfloat getXChange();
	GLfloat getYChange();
	GLfloat getmuevex() { return muevex; }
	bool getShouldClose() {
		return  glfwWindowShouldClose(mainWindow);}
	bool* getsKeys() { return keys; }
    // Conserva una pulsacion aunque se suelte antes del siguiente cuadro.
    bool getTeclaPresionada(int tecla) { bool p = pulsadas[tecla]; pulsadas[tecla] = false; return p; }
	bool getPelicanPresionado() { bool p = pelicanPresionado; pelicanPresionado = false; return p; }
	void swapBuffers() { return glfwSwapBuffers(mainWindow); }
	
	~Window();
private: 
	GLFWwindow *mainWindow;
	GLint width, height;
	bool keys[1024];
	bool pulsadas[1024] = {};
	bool pelicanPresionado = false;
	GLint bufferWidth, bufferHeight;
	void createCallbacks();
	GLfloat lastX;
	GLfloat lastY;
	GLfloat xChange = 0;
	GLfloat yChange = 0;
	GLfloat muevex;
	bool mouseFirstMoved = true;
	static void ManejaTeclado(GLFWwindow* window, int key, int code, int action, int mode);
	static void ManejaMouse(GLFWwindow* window, double xPos, double yPos);

};

