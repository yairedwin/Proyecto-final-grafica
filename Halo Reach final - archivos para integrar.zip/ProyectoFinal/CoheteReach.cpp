#include "CoheteReach.h"
#include "Model.h"
#include "Material.h"
#include <glfw3.h>
#include <gtc/matrix_transform.hpp>
#include <gtc/type_ptr.hpp>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <vector>
#include <cmath>
#include <cstdio>

namespace {
    // La misma idea de E10: guardar poses y avanzar interpolando entre dos cuadros.
    // Ahora cada cuadro tiene la posicion y el giro de las tres etapas y la capsula.
    struct Pose { glm::vec3 posicion; float giro; };
    struct Cuadro { float tiempo; Pose pieza[4]; };
    Model modelos[4];
    std::vector<Cuadro> cuadros;
    Pose actual[4];
    int inicioOrbita = 0, cuadro = 0;
    float reloj = 0;
    bool reproduciendo = false;
    const char* archivo = "keyframes_cohete_reach.txt";

    void imprimir(int i, const char* accion) {
        printf("%s | KEYFRAME %d/%d | t=%.2f s\n", accion, i + 1, (int)cuadros.size(), cuadros[i].tiempo);
        for (int p = 0; p < 4; p++) {
            const Pose& a = cuadros[i].pieza[p];
            printf("  %s %d: X=%.3f Y=%.3f Z=%.3f giroZ=%.3f\n",
                p == 3 ? "Capsula" : "Etapa", p + 1, a.posicion.x, a.posicion.y, a.posicion.z, a.giro);
        }
        fflush(stdout);
    }
    void reiniciar() {
        reloj = 0; cuadro = 0; reproduciendo = false;
        if (!cuadros.empty()) for (int p = 0; p < 4; p++) actual[p] = cuadros[0].pieza[p];
    }
    bool leer() {
        std::ifstream entrada(archivo);
        std::string linea;
        std::vector<Cuadro> nuevos;
        int cantidad = 0, orbita = -1;
        while (std::getline(entrada, linea)) {
            if (linea.empty() || linea[0] == '#') continue;
            std::istringstream fila(linea);
            if (cantidad == 0) {
                if (!(fila >> cantidad >> orbita) || cantidad < 2 || cantidad > 200 || orbita < 0 || orbita >= cantidad - 1) return false;
                continue;
            }
            Cuadro c;
            if (!(fila >> c.tiempo) || !std::isfinite(c.tiempo)) return false;
            for (Pose& p : c.pieza) {
                if (!(fila >> p.posicion.x >> p.posicion.y >> p.posicion.z >> p.giro)) return false;
                if (!std::isfinite(p.posicion.x) || !std::isfinite(p.posicion.y) || !std::isfinite(p.posicion.z) || !std::isfinite(p.giro)) return false;
            }
            if ((nuevos.empty() && c.tiempo != 0) || (!nuevos.empty() && c.tiempo <= nuevos.back().tiempo)) return false;
            nuevos.push_back(c);
        }
        if ((int)nuevos.size() != cantidad || cantidad < 2) return false;
        // El ultimo cuadro debe coincidir con el inicio de la orbita para evitar un salto.
        for (int p = 0; p < 4; p++) {
            if (glm::distance(nuevos.back().pieza[p].posicion, nuevos[orbita].pieza[p].posicion) > 0.01f ||
                fabs(nuevos.back().pieza[p].giro - nuevos[orbita].pieza[p].giro) > 0.01f) return false;
        }
        cuadros = nuevos; inicioOrbita = orbita; reiniciar();
        printf("LEIDOS %d KEYFRAMES de %s. La orbita repite desde el cuadro %d.\n", cantidad, archivo, orbita + 1);
        for (int i = 0; i < cantidad; i++) imprimir(i, "TXT CARGADO");
        return true;
    }
    void guardar() {
        if (cuadros.empty()) return;
        std::ofstream salida(archivo);
        salida << "# PRACTICA 10 - 317136421 - Saturn V integrado en Reach\n"
            << "# Cantidad de cuadros e indice de inicio de orbita (desde cero).\n"
            << cuadros.size() << ' ' << inicioOrbita << "\n"
            << "# tiempo | etapa1 X Y Z giroZ | etapa2 X Y Z giroZ | etapa3 X Y Z giroZ | capsula X Y Z giroZ\n"
            << "# Segundos, unidades del proyecto y grados. Interpolacion lineal.\n" << std::fixed << std::setprecision(3);
        for (const Cuadro& c : cuadros) {
            salida << c.tiempo;
            for (const Pose& p : c.pieza) salida << ' ' << p.posicion.x << ' ' << p.posicion.y << ' ' << p.posicion.z << ' ' << p.giro;
            salida << '\n';
        }
        salida.close();
        if (!salida) { printf("ERROR al guardar %s\n", archivo); return; }
        printf("F5: GUARDADOS %d KEYFRAMES en %s\n", (int)cuadros.size(), archivo);
        fflush(stdout);
    }
}

void CargarCoheteReach() {
    const char* rutas[] = { "Models/SaturnV/etapa1.obj", "Models/SaturnV/etapa2.obj",
        "Models/SaturnV/etapa3.obj", "Models/SaturnV/capsula.obj" };
    for (int i = 0; i < 4; i++) modelos[i].LoadModel(rutas[i]);
    printf("\nCOHETE DE E10 EN REACH - PRACTICA 10\n"
        "ESPACIO: iniciar / pausar / continuar. RETROCESO: reiniciar.\n"
        "F5: guardar TXT. F6: cargar TXT e imprimir los cuadros en consola.\n"
        "5: camara de la capsula. 6: vista de Reach y etapas. 1-4: camaras originales.\n"
        "Despegue, separacion de tres etapas y caida al piso; la capsula queda orbitando.\n");
    if (!leer()) printf("ERROR: falta %s o contiene cuadros invalidos. No se inicia la animacion.\n", archivo);
}

void TeclaCoheteReach(int tecla) {
    if (tecla == GLFW_KEY_F6) {
        if (!leer()) printf("F6: TXT invalido; se conserva la animacion anterior.\n");
    }
    if (tecla == GLFW_KEY_F5) guardar();
    if (tecla == GLFW_KEY_BACKSPACE) { reiniciar(); printf("Cohete reiniciado en Reach.\n"); }
    if (tecla == GLFW_KEY_SPACE && !cuadros.empty()) {
        reproduciendo = !reproduciendo;
        printf("%s | t=%.2f s\n", reproduciendo ? "REPRODUCIENDO KEYFRAMES" : "PAUSA", reloj);
        imprimir(cuadro, "CUADRO ACTUAL");
    }
    fflush(stdout);
}

void ActualizarCoheteReach(float dt) {
    if (cuadros.empty()) return;
    if (reproduciendo) {
        reloj += dt;
        if (reloj >= cuadros.back().tiempo) {
            reloj = cuadros[inicioOrbita].tiempo + fmod(reloj - cuadros.back().tiempo,
                cuadros.back().tiempo - cuadros[inicioOrbita].tiempo);
            cuadro = inicioOrbita;
            imprimir(cuadro, "ORBITA: SE REPITE SOLO LA CAPSULA; ETAPAS EN EL PISO");
        }
        while (cuadro + 1 < (int)cuadros.size() && reloj >= cuadros[cuadro + 1].tiempo) {
            cuadro++; imprimir(cuadro, "KEYFRAME REPRODUCIDO");
        }
        const Cuadro& a = cuadros[cuadro];
        const Cuadro& b = cuadros[cuadro + 1];
        float u = (reloj - a.tiempo) / (b.tiempo - a.tiempo);
        for (int p = 0; p < 4; p++) {
            actual[p].posicion = glm::mix(a.pieza[p].posicion, b.pieza[p].posicion, u);
            actual[p].giro = a.pieza[p].giro + u * (b.pieza[p].giro - a.pieza[p].giro);
        }
    }
    char titulo[256];
    snprintf(titulo, sizeof(titulo), "Reach | Cohete KF %d/%d | %.1f s | %s | Espacio: iniciar/pausa | 5: capsula, 6: Reach | F5 guardar, F6 leer TXT",
        cuadro + 1, (int)cuadros.size(), reloj, reproduciendo ? "REPRODUCIENDO" : "PAUSA");
    glfwSetWindowTitle(glfwGetCurrentContext(), titulo);
}

glm::vec3 PosicionCapsulaReach() { return actual[3].posicion; }

void DibujarCoheteReach(GLuint modelo, GLuint color, GLuint especular, GLuint brillo) {
    if (cuadros.empty()) return;
    Material acabado(0.15f, 32);
    acabado.UseMaterial(especular, brillo);
    glUniform3f(color, 1, 1, 1);
    for (int i = 0; i < 4; i++) {
        glm::mat4 m = glm::translate(glm::mat4(1), actual[i].posicion);
        m = glm::rotate(m, glm::radians(actual[i].giro), glm::vec3(0, 0, 1));
        m = glm::scale(m, glm::vec3(1.4f));
        glUniformMatrix4fv(modelo, 1, GL_FALSE, glm::value_ptr(m));
        modelos[i].RenderModel();
    }
}
