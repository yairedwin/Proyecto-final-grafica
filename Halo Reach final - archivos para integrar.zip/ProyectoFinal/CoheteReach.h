#pragma once
#include <glew.h>
#include <glm.hpp>

void CargarCoheteReach();
void ActualizarCoheteReach(float dt);
void TeclaCoheteReach(int tecla);
void DibujarCoheteReach(GLuint modelo, GLuint color, GLuint especular, GLuint brillo);
glm::vec3 PosicionCapsulaReach();
