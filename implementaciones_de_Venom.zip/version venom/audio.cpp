#define MINIAUDIO_IMPLEMENTATION
#include "miniaudio.h"
#include "audio.h"
#include <stdio.h>
#include <string.h>
#include <math.h>
#ifdef _WIN32
#include <direct.h>
#endif

// DIAGNOSTICO: con 1, los primeros 5 s de ejecucion suena la musica de Venom sin importar donde este la camara,
// y cada 3 s se imprime el estado en la consola. Cuando todo funcione, ponlo en 0
#define AUDIO_DIAGNOSTICO 1

static ma_engine motor;
static ma_sound musicaVenom, musicaLuna;
static bool motorListo = false, venomListo = false, lunaListo = false;
static bool avisoVenom = false, avisoLuna = false;
static float volVenom = 0.0f, volLuna = 0.0f;	// volumen actual (suavizado)
static float tTotal = 0.0f, tAviso = 0.0f;

// volumen maximo de cada cancion
static const float VOL_MAX_VENOM = 0.55f;
static const float VOL_MAX_LUNA = 0.90f;

// intenta abrir la ruta tal cual y, si no existe, solo el nombre del archivo (junto al ejecutable o al proyecto)
static bool cargar(const char* ruta, ma_sound* s)
{
	const char* nombre = strrchr(ruta, '/');
	nombre = nombre ? nombre + 1 : ruta;
	const char* intentos[2] = { ruta, nombre };
	for (int i = 0; i < 2; i++) {
		// MA_SOUND_FLAG_STREAM: se decodifica por partes, los mp3 largos no se cargan completos en memoria
		ma_result r = ma_sound_init_from_file(&motor, intentos[i], MA_SOUND_FLAG_STREAM, NULL, NULL, s);
		if (r == MA_SUCCESS) {
			ma_sound_set_looping(s, MA_TRUE);
			ma_sound_set_volume(s, 0.0f);
			ma_sound_start(s);
			printf("Audio: abierto %s\n", intentos[i]);
			return true;
		}
		printf("Audio: no se pudo abrir %s (%s)\n", intentos[i], ma_result_description(r));
	}
	return false;
}

bool AudioIniciar(const char* rutaVenom, const char* rutaLuna)
{
	printf("Audio: AudioIniciar llamado\n");
#ifdef _WIN32
	char cwd[512];
	if (_getcwd(cwd, sizeof(cwd))) printf("Audio: carpeta de trabajo = %s (aqui debe existir la carpeta Audio)\n", cwd);
#endif
	ma_result r = ma_engine_init(NULL, &motor);
	if (r != MA_SUCCESS) { printf("Audio: no se pudo iniciar el motor (%s)\n", ma_result_description(r)); return false; }
	motorListo = true;
	printf("Audio: motor iniciado, %u Hz\n", (unsigned)ma_engine_get_sample_rate(&motor));
	venomListo = cargar(rutaVenom, &musicaVenom);
	lunaListo = cargar(rutaLuna, &musicaLuna);
	return venomListo && lunaListo;
}

void AudioActualizar(float dt, float objetivoVenom, float objetivoLuna)
{
	if (!motorListo) return;
	tTotal += dt;
#if AUDIO_DIAGNOSTICO
	if (tTotal < 5.0f) objetivoVenom = 1.0f;	// prueba de arranque
#endif
	if (objetivoVenom < 0.0f) objetivoVenom = 0.0f; if (objetivoVenom > 1.0f) objetivoVenom = 1.0f;
	if (objetivoLuna < 0.0f) objetivoLuna = 0.0f; if (objetivoLuna > 1.0f) objetivoLuna = 1.0f;

	// Venom entra y sale en ~1.5 s (fade); la luna sigue a la distancia mas rapido para que se sienta el acercamiento
	float kV = 1.0f - expf(-dt / 0.5f);
	float kL = 1.0f - expf(-dt / 0.15f);
	volVenom += (objetivoVenom - volVenom) * kV;
	volLuna += (objetivoLuna - volLuna) * kL;

	// ducking: mientras mas cerca de la luna, mas se apaga la musica de Venom
	float venomFinal = volVenom * (1.0f - 0.9f * volLuna);
	if (venomListo) ma_sound_set_volume(&musicaVenom, venomFinal * VOL_MAX_VENOM);
	if (lunaListo) ma_sound_set_volume(&musicaLuna, volLuna * VOL_MAX_LUNA);

	// avisos de una sola vez en la consola para saber que el volumen ya esta subiendo
	if (!avisoVenom && volVenom > 0.05f) { avisoVenom = true; printf("Audio: sonando la musica de Venom\n"); }
	if (!avisoLuna && volLuna > 0.05f) { avisoLuna = true; printf("Audio: sonando Final Hours de la luna\n"); }

#if AUDIO_DIAGNOSTICO
	tAviso += dt;
	if (tAviso > 3.0f) {
		tAviso = 0.0f;
		printf("Audio: t=%.1f s, objetivo venom=%.2f luna=%.2f, volumen venom=%.2f luna=%.2f, reproduciendo venom=%d luna=%d\n",
			tTotal, objetivoVenom, objetivoLuna, volVenom, volLuna,
			venomListo ? (int)ma_sound_is_playing(&musicaVenom) : -1, lunaListo ? (int)ma_sound_is_playing(&musicaLuna) : -1);
	}
#endif
}

void AudioCerrar()
{
	if (venomListo) ma_sound_uninit(&musicaVenom);
	if (lunaListo) ma_sound_uninit(&musicaLuna);
	if (motorListo) ma_engine_uninit(&motor);
	motorListo = venomListo = lunaListo = false;
}
