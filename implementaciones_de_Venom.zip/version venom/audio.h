#pragma once
// audio del proyecto (miniaudio): musica de Venom y "Final Hours" de la luna de Majora's Mask
// requiere miniaudio.h junto a estos archivos

// abre el motor y deja las dos canciones en loop con volumen 0; regresa false si algo no se pudo cargar
bool AudioIniciar(const char* rutaVenom, const char* rutaLuna);

// se llama una vez por cuadro con los volumenes objetivo (0 a 1) de cada cancion
// el suavizado y el "ducking" (Venom baja cuando la luna se acerca) se hacen aqui adentro
void AudioActualizar(float dt, float objetivoVenom, float objetivoLuna);

void AudioCerrar();
